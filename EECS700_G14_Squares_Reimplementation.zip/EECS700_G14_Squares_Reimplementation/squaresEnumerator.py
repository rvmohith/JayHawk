from sys import argv
import tyrell.spec as S
from tyrell.interpreter import PostOrderInterpreter, GeneralError
from tyrell.enumerator import *
from tyrell.decider import Example, ExampleConstraintPruningDecider
from tyrell.synthesizer import Synthesizer
import rpy2.robjects as robjects
from itertools import permutations
import warnings
from rpy2.rinterface import RRuntimeWarning
import sys
import os
import pandas as pd
import numpy as np

warnings.filterwarnings("ignore", category=RRuntimeWarning)

counter_ = 0
distinct = False
getProgram = False
final_program = ''
_tables = dict()
output_attrs = ""
attributes = []
robjects.r('''
	library(dplyr)
	library(dbplyr)
	library(tidyr)
	library(stringr)
	options(warn=-1)
   ''')


def get_fresh_name():
    global counter_
    counter_ = counter_ + 1
    return f'RET_DF{counter_}'


def get_fresh_col():
    global counter_
    counter_ = counter_ + 1
    return f'COL{counter_}'


def get_type(df, index):
    return df.iloc[:, index].dtype

def getConst(cons):
    global attributes
    try:
        if isinstance(cons, int):
            return str(cons)
    except ValueError:
        if cons == "max(n)" or cons in attributes:
            return str(cons)
        else:
            return f'"{cons}"'


def getColsPermutations(cols, num):
    if num == 0:
        return []
    return [", ".join(a) for a in permutations(cols, num)] + getColsPermutations(cols, num - 1)


def eq_r(actual, expect):
    global distinct
    _rscript = 'all.equal(lapply({lhs}, as.character),lapply({rhs}, as.character))'.format(lhs=actual, rhs=expect)
    try:
        ret_val = robjects.r(_rscript)
    except:
        return False
    return True == ret_val[0]


def findConst(consts):
    for const in consts:
        try:
            if int(const[1:-1]):
                return True
        except ValueError:
            pass
    return False


class SquaresInterpreter(PostOrderInterpreter):
    def eval_ColInt(self, v):
        return v

    def eval_unused(self, node, args):
        return get_fresh_name()

    def eval_ColList(self, v):
        return v

    def eval_const(self, node, args):
        return args[0]

    def eval_select(self, node, args):
        global final_program, getProgram
        ret_df_name = get_fresh_name()
        _tables[ret_df_name] = counter_
        rscript = '{ret_df} <- {table} %>% ungroup() %>% select({cols})'.format(ret_df=ret_df_name, table=args[0],
                                                                                cols=(args[1]))
        if args[2] == "distinct":
            rscript += ' %>% distinct()'
        if getProgram:
            final_program += rscript + "\n"
        try:
            ret_val = robjects.r(rscript)
            return ret_df_name
        except:
            raise GeneralError()

    def eval_filter(self, node, args):
            global final_program, getProgram
            ret_df_name = get_fresh_name()
            _tables[ret_df_name] = counter_
            if "str_detect" not in args[1]:
                col, op, const = args[1].split(" ")
                rscript = '{ret_df} <- {table} %>% ungroup() %>% filter({col} {op} {const})'.format(ret_df=ret_df_name,
                                                                                                    table=args[0], op=op,
                                                                                                    col=col, const=getConst(
                        const)) if const != "max(n)" else '{ret_df} <- filter({table}, {col} {op} {const})'.format(
                    ret_df=ret_df_name, table=args[0], op=op, col=col, const="max(n)")
            else:
                col, string = args[1].split("|")
                rscript = '{ret_df} <- {table} %>% ungroup() %>% filter({col}, {const}))'.format(ret_df=ret_df_name,
                                                                                                 table=args[0], col=col,
                                                                                                 const="\"" + string[
                                                                                                              :-1] + "\"")

            if getProgram:
                final_program += rscript + "\n"
            try:
                ret_val = robjects.r(rscript)
                return ret_df_name
            except:
                raise GeneralError()

    def eval_filters(self, node, args):
        global final_program, getProgram
        ret_df_name = get_fresh_name()
        _tables[ret_df_name] = counter_
        if "str_detect" not in args[1]:
            col, op, const = args[1].split(" ")
            const = getConst(const) if const != "max(n)" else "max(n)"
            arg1 = col + " " + op + " " + const
        else:
            col, string = args[1].split("|")
            arg1 = col + ", " + "\"" + string[:-1] + "\")"
        if "str_detect" not in args[2]:
            col, op, const = args[2].split(" ")
            const = getConst(const) if const != "max(n)" else "max(n)"
            arg2 = col + " " + op + " " + const
        else:
            col, string = args[2].split("|")
            arg2 = col + ", " + "\"" + string[:-1] + "\")"

        rscript = '{ret_df} <- {table} %>% ungroup() %>% filter({arg1} {Operator} {arg2})'.format(ret_df=ret_df_name,
                                                                                                  table=args[0],
                                                                                                  arg1=arg1, arg2=arg2,
                                                                                                  Operator=args[3])
        if getProgram:
            final_program += rscript + "\n"
        try:
            ret_val = robjects.r(rscript)
            return ret_df_name
        except:
            raise GeneralError()

    def eval_summariseGrouped(self, node, args):
        global final_program, getProgram
        ret_df_name = get_fresh_name()
        _tables[ret_df_name] = counter_
        if "paste" in args[1]:
            args[1] = '{at} = paste({at}, collapse=:)'.format(at=args[1].split("|")[1])
        rscript = '{ret_df} <- {table} %>% group_by({cols}) %>% summarise({cond})'.format(ret_df=ret_df_name,
                                                                                          table=args[0], cols=(args[2]),
                                                                                          cond=args[1].replace(":",
                                                                                                               "\":\""))
        if getProgram:
            final_program += rscript + "\n"
        try:
            ret_val = robjects.r(rscript)
            return ret_df_name
        except:
            raise GeneralError()

    def eval_summarise(self, node, args):
        global final_program, getProgram
        ret_df_name = get_fresh_name()
        _tables[ret_df_name] = counter_
        if "paste" in args[1]:
            args[1] = '{at} = paste({at}, collapse=\":\")'.format(at=args[1].split("|")[1])
        rscript = '{ret_df} <- {table} %>% summarise({cond})'.format(ret_df=ret_df_name, table=args[0], cond=args[1])

        if getProgram:
            final_program += rscript + "\n"
        try:
            ret_val = robjects.r(rscript)
            return ret_df_name
        except:
            raise GeneralError()

    def eval_inner_join(self, node, args):
        global final_program, getProgram
        ret_df_name = get_fresh_name()
        _tables[ret_df_name] = counter_
        rscript = '{ret_df} <- inner_join({t1}, {t2})'.format(
            ret_df=ret_df_name, t1=args[0], t2=args[1])
        if getProgram:
            final_program += rscript + "\n"
        try:
            ret_val = robjects.r(rscript)
            return ret_df_name
        except:

            raise GeneralError()

    def eval_left_join(self, node, args):
        global final_program, getProgram
        ret_df_name = get_fresh_name()
        _tables[ret_df_name] = counter_
        rscript = '{ret_df} <- left_join({t1}, {t2})'.format(
                  ret_df=ret_df_name, t1=args[0], t2=args[1])

        if getProgram:
            final_program += rscript + "\n"
        try:
            ret_val = robjects.r(rscript)
            return ret_df_name
        except:
            raise GeneralError()

    def apply_row(self, v):
        df = v
        if isinstance(v, str):
            df = robjects.r(v)
        return df.nrow

    def apply_col(self, v):
        df = v
        if isinstance(v, str):
            df = robjects.r(v)
        return df.ncol

    def apply_name(self, v):
        return _tables[v]

def divide_int_str_constants(const):
    str_const = [c for c in const if not c.isdigit()]
    int_const = [c for c in const if c.isdigit() or c == '0']
    return str_const, int_const

def divide_int_str_attributes(files, attrs):
    str_attr, int_attr = [], []

    for a in attrs:
        if a == "n" and a not in int_attr:
            int_attr.append(a)

        for i in files:
            with open(i, 'r') as f:
                columns = f.readline().strip().split(",")
                if a in columns:
                    ind = columns.index(a)
                    try:
                        value = f.readline().strip().split(",")[ind]
                        if value == '0' or int(value):
                            if a not in int_attr:
                                int_attr.append(a)
                    except ValueError:
                        if a not in str_attr:
                            str_attr.append(a)
    return str_attr, int_attr

def find_filter_conditions(strconst, intconst, strattr, intattr, new_int_attr, aggrs, files, necessary_conditions,
                           summarise_conditions):
    cond = []
    intops = ["==", ">", "<", ">=", "<="]
    strops = ["==", "!="]
    happens_before = []
    for sc in strconst + intconst:
        necessary_conditions.append([])
        for sa in strattr:
            att = False
            for i in files:
                if att:
                    break
                with open(i, 'r') as f:
                    columns = f.readline()[:-1].split(",")
                    if sa in columns:
                        ind = columns.index(sa)
                        for l in f:
                            if l[:-1].split(",")[ind] == sc:
                                att = True
                                break
                    else:
                        continue
            if 'like' in aggrs:
                cond.append('str_detect({sa}|{sc})'.format(sa=sa, sc=sc))
                necessary_conditions[-1].append(cond[-1])

            if not att:
                continue
            for so in strops:
                cond.append('{sa} {so} {sc}'.format(sa=sa, so=so, sc=sc))
                necessary_conditions[-1].append(cond[-1])

    for ic in intconst:
        necessary_conditions.append([])
        for ia in intattr + new_int_attr:
            if ic == ia:
                continue
            for io in intops:
                cond.append('{ia} {io} {ic}'.format(ia=ia, io=io, ic=ic))
                necessary_conditions[-1].append(cond[-1])
                if ia == "n":
                    happens_before.append((cond[-1], "n = n()"))
    for ic in new_int_attr:
        for ia in intattr + new_int_attr:
            if ic == ia:
                continue
            for io in intops:
                cond.append('{ia} {io} {ic}'.format(ia=ia, io=io, ic=ic))
                for sc in summarise_conditions:
                    if ic in sc:
                        happens_before.append((cond[-1], sc))
    necessary_conditions = list(filter(lambda a: a != [], necessary_conditions))
    if "max(n)" in aggrs:
        cond.append("n == max(n)")
        happens_before.append((cond[-1], "n = n()"))
        necessary_conditions.append([cond[-1]])
    return cond, necessary_conditions, happens_before



def find_summarise_conditions(int_attr, str_attr, aggrs, necessary_conditions):
    cond = []
    new_int_attr = []
    for a in aggrs:
        if a == "like" or "max(n)" == a:
            continue
        necessary_conditions.append([])
        if "n" == a:
            cond.append(f'{a} = {a}()')
        elif 'concat' in a:
            cond.extend([f'paste|{at}' for at in int_attr + str_attr])
        else:
            cond.extend([f'{a}{ia} = {a}({ia})' for ia in int_attr])
            new_int_attr.extend([f'{a}{ia}' for ia in int_attr])
        necessary_conditions[-1].extend(cond)
    return [a for a in necessary_conditions if a], new_int_attr, cond


def find_conditions(files, const, attrs, aggrs, bools):
    global attributes
    nec_cond = []
    strconst, intconst = divide_int_str_constants(const)
    strattr, intattr = divide_int_str_attributes(files, attrs)
    nec_cond, new_int_attr, sum_cond = find_summarise_conditions(intattr, strattr, aggrs,nec_cond)
    filt_cond, nec_cond, happens_before = find_filter_conditions(strconst, intconst, strattr, intattr,
                                                                             new_int_attr, aggrs, files,
                                                                             nec_cond, sum_cond)
    attributes = intattr + new_int_attr
    return filt_cond, sum_cond, nec_cond, happens_before

def find_necessary_conditions(conds):
    return "\n".join(f"predicate constant_occurs(\"{','.join(c)}\");"
                     for c in conds if c != [])
def happensBefore(conds):
    return "\n".join(f"predicate happens_before(\"{c[0]}\",\"{c[1]}\");"
                     for c in conds if c != ())


def DSL():
    global counter_
    global _tables
    global output_attrs
    prog_out = ""
    Operators = ""
    concat = ""
    input_tables, ags, cns, ats, bls, db_columns = [], [], [], [], [], []

    filtersOne = "\nfunc filter: Table r -> Table a, FilterCondition f {\n row(r) <= row(a);\n col(r) == col(a);\n}"
    filters = filtersOne
    filterAndOr = "\nfunc filters: Table r -> Table a, FilterCondition f, FilterCondition g, Op o {\n row(r) <= row(a);\n col(r) == col(a);\n}"
    filterPredicateOne = "\npredicate is_not_parent(inner_join3, filter, 100);\npredicate is_not_parent(inner_join4, filter, 100);\npredicate is_not_parent(filter, filter, 100);\npredicate distinct_inputs(filter);\n"
    filterPredicate = filterPredicateOne
    filterPredicateTwo = "predicate distinct_filters(filters, 1, 2);\npredicate is_not_parent(filters, filters, 100);\npredicate is_not_parent(inner_join, filters, 100);\npredicate is_not_parent(inner_join3, filters, 100);\npredicate is_not_parent(inner_join4, filters, 100);\npredicate distinct_inputs(filters);"
    summarise = "\nfunc summariseGrouped: Table r -> Table a, SummariseCondition s, Cols b {\n row(r) <= row(a);\n col(r) <= 3;\n}\n\npredicate is_not_parent(inner_join4, summariseGrouped, 100);\npredicate is_not_parent(summariseGrouped, summariseGrouped, 100);"

    f_in = open(argv[-1], 'r')
    inputs = f_in.readline()[:-1].split(":")[1].replace(" ", "").split(",")
    prog_out += "con <- DBI::dbConnect(RSQLite::SQLite(), \":memory:\")\n"
    for i in inputs:
        _script = 'input{cnt} <- read.table("{file}", sep =",", header=T)\ninput{cnt}\n'.format(file=i, cnt=counter_)
        prog_out += _script
        prog_out += 'input{cnt} <- copy_to(con,input{cnt})\n'.format(cnt=counter_)
        benchmark1_input = robjects.r(_script)
        input_tables.append('input{cnt}'.format(cnt=counter_))
        _tables[input_tables[-1]] = counter_
        counter_ += 1
        with open(i, 'r') as f:
            db_columns = list(set(db_columns + f.readline()[:-1].split(",")))

    output = f_in.readline()[:-1].split(":")[1].replace(" ", "")
    _script = 'expected_output <- read.table("{file}", sep =",", header=T)\nexpected_output\n'.format(file=output)
    prog_out += _script
    # print(_script)
    _tables['expected_output'] = counter_
    counter_ += 1
    benchmark1_output = robjects.r(_script)
    # read the list of constants from the input
    consts = f_in.readline()[:-1].replace(" ", "").split(":", 1)
    intConst = findConst(consts[1].replace(" ", "").split(","))
    # filterFlag = 0
    if (consts[1] != ''):
        filterFlag = 1
        consts_temp = ""
        if len(consts[1].split(",")) > 1:
            filterFlag = 2
            filters = filterAndOr
            filterPredicate = filterPredicateTwo
            Operators = "enum Op{\n \"|\", \"&\"\n}"
        cns = consts[1].replace(" ", "").replace("\"", "").split(",")
    else:
        filterPredicate, filters, consts = "", "", ""

    aggrs = f_in.readline()[:-1].replace(" ", "").split(":")
    if aggrs[1] != '':
        ags = aggrs[1].replace(" ", "").replace("\"", "").split(",")
        for a in ags:
            if a == "concat":
                ags.remove(a)
                concat = "\nfunc unite: Table r -> Table a, Col c, Col d {\n row(r) <= row(a);\n col(r) < col(a);\n}"
        if (len(ags) == 1 and "like" in ags) or len(ags) == 0:
            summarise = ""

    else:
        aggrs = ""
        summarise = ""
    if "\"max(n)\"" in aggrs:
        cns.append("max(n)")
        aggrs = aggrs.replace(",\"max(n)\"", "")
    file_path = 'example/squares.tyrell'
    attrs = f_in.readline()[:-1].replace(" ", "").split(":")
    if (attrs[1] != ''):
        ats = list(attrs[1].replace(" ", "").replace("\"", "").split(","))
        ats = ats + ["n"] if "n" in ags and intConst else ats
    elif "\"n\"" in aggrs:
        ats.append("n")
    else:
        attrs = ""
    hasBools = False
    bools = f_in.readline()[:-1].replace(" ", "").split(":")
    if "bools" in bools:
        hasBools = True
    if not hasBools:
        loc = int(bools[1])
    else:
        loc = int(f_in.readline()[:-1].replace(" ", "").split(":")[1])
    filterConditions, summariseConditions, necessary_conditions, happens_before = find_conditions(inputs, cns, ats, ags,
                                                                                                  bls)
    if filters == "" and filterConditions != []:
        filters = filtersOne
        filterPredicate = "\npredicate is_not_parent(filter, filter, 100);"

    if len(necessary_conditions) > 1:
        filters = filtersOne + filterAndOr
        filterPredicate = "predicate distinct_filters(filters, 1, 2);\n\npredicate is_not_parent(filters, filter, 100);\npredicate is_not_parent(filter, filters, 100);\npredicate is_not_parent(filter, filter, 100);\npredicate is_not_parent(filters, filters, 100);"
        Operators = "enum Op{\n \"|\", \"&\"\n}"
    necessary_conditions = find_necessary_conditions(necessary_conditions)
    necessary_conditions += happensBefore(happens_before)
    with open(output, 'r') as f:
        cols = f.readline()
    output_attrs = cols[:-1]
    cols = str(getColsPermutations(str(db_columns)[1:-1].replace("'", "").replace(" ", "").split(","), 2))[
           1:-1].replace("'", "\"")
    oneColumn = str(getColsPermutations(str(db_columns)[1:-1].replace("'", "").replace(" ", "").split(","), 1))[
                1:-1].replace("'", "\"")
    with open(dir + file_path, 'r') as f:
        spec_str = f.read()
    fil_conditions = "enum FilterCondition{\n" + str(filterConditions)[1:-1].replace("'",
                                                                                     "\"") + "\n}\n" if filterConditions != [] else ""
    sum_conditions = "enum SummariseCondition{\n" + str(summariseConditions)[1:-1].replace("'",
                                                                                           "\"") + "\n}\n" if summariseConditions != [] else ""

    return spec_str.format(cols=cols, Tables=str("Table, " * len(inputs))[:-2], summarise=summarise, filters=filters,
                           filterPred=filterPredicate, FilterConditions=fil_conditions,
                           SummariseConditions=sum_conditions, Op=Operators, necessaryConditions=necessary_conditions,
                           SelectCols=str("\"" + output_attrs + "\""), col=oneColumn,
                           concat=concat), input_tables, prog_out, loc


def main(seed=None):
    global getProgram, final_program
    if not debug:
        sys.stderr = open(dir + 'output.err', 'w+')
    warnings.filterwarnings("ignore", category=RRuntimeWarning)
    warnings.filterwarnings('ignore')
    dsl, input_tables, prog_out, loc = DSL()
    spec = S.parse(dsl)
    loc = 1
    while (True):
        if argv[1] == "tree":
            enumerator = SmtEnumerator(spec, depth=loc + 1, loc=loc)
        else:
            if "-off" in argv:
                enumerator = LinesEnumerator(spec, depth=loc + 1, loc=loc)
            elif "-on" in argv:
                enumerator = LinesEnumerator(spec, depth=loc + 1, loc=loc, break_sym_online=True)
            else:
                enumerator = LinesEnumerator(spec, depth=loc + 1, loc=loc, sym_breaker=False)

        synthesizer = Synthesizer(
            # loc: # of function productions
            enumerator=enumerator,
            # decider=ExampleConstraintDecider(
            decider=ExampleConstraintPruningDecider(
                spec=spec,
                interpreter=SquaresInterpreter(),
                examples=[
                    Example(input=input_tables, output='expected_output'),
                ],
                equal_output=eq_r
            )
        )

        prog = synthesizer.synthesize()
        if prog is not None:
            getProgram = True
            interpreter = SquaresInterpreter()
            evaluation = interpreter.eval(prog, input_tables)
            if dir == "./":
                print()
                if "-nr" not in argv:
                    print("R based solution: \n")
                    print(prog_out)
                    print(final_program)

                print("SQL query is: \n")
            robjects.r('{rscript}'.format(rscript=prog_out + final_program))
            sql_query = robjects.r('sql_render({result_table})'.format(result_table=evaluation))
            if dir == "./":
                print("...")
            return final_program, (str(sql_query)[6:])
        else:
            loc = loc + 1



debug = False
dir = "./"
if __name__ == '__main__':
    if "-d" in argv:
        debug = True
    seed = None
    if "-h" in argv:
        exit(
            "Usage: python3 squaresEnumerator.py [tree|lines] [flags -h, ...] input.in\nflags:\n-on : computing symmetries online\n-off : computing symmetries offline\n-d : debug info\n\n-nr : only SQL solution\n\nDefault: lines enumerator and without symmetry breaking")
    if len(argv) > 1:
        try:
            seed = int(argv[1])
        except ValueError:
            pass
    prog = main(seed)


class Squares(object):
    def __init__(self):
        super(Squares, self).__init__()
        self.template = "inputs: {inputs}\noutput: {output}\nconst: {const}\naggrs: {aggrs}\nattrs: {attrs}\nbools:\nloc: {loc}\n"
    def synthesize(self, inputs, output_ex, const="", aggrs="", attrs="", loc=0):
        global argv, dir
        dir = "../"
        ins = list([])
        temp = self.template
        try:
            path, dirs, files = next(os.walk("../users/files"))
        except:
            path, dirs, files = next(os.walk("users/files"))
            dir = "./"
        file_count = str(len(files) + 1)
        ic = 0
        for i in inputs:
            input = open(dir + "users/tables/" + "i" + str(file_count) + str(ic), "w+")
            input.write(i)
            input.close()
            ins.append(dir + "users/tables/" + "i" + str(file_count) + str(ic))
            ic += 1
        output = open(dir + "users/tables/" + "o" + str(file_count), "w+")
        output.write(output_ex)
        output.close()
        output = dir + "users/tables/o" + str(file_count)
        input_file_name = dir + "users/files/" + "f" + str(file_count)
        input_file = open(input_file_name, "w+")
        inputs = str(ins).replace("\'", "").replace("]", "").replace("[", "")
        input_file.write(
            temp.format(inputs=inputs, output=output, const="\"" + const.replace(",", "\",\"").replace(" ", "") + "\"",
                        aggrs="\"" + aggrs.replace(",", "\",\"").replace(" ", "") + "\"",
                        attrs="\"" + attrs.replace(",", "\",\"").replace(" ", "") + "\"", loc=str(loc)).replace("\"\"",
                                                                                                                ""))
        input_file.close()
        argv = []
        argv.append("lines")
        argv.append(input_file_name)
        return main()

