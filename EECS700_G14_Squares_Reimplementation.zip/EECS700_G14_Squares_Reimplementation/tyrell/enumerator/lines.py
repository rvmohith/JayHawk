from z3 import *
from collections import deque
from .enumerator import Enumerator
from .gen_lattices import SymmetryFinder
from .. import dsl as D
from copy import deepcopy
import time


class Node(object):
    def __init__(self, nb=None):
        self.nb = nb
        self.var = None
        self.parent = None
        self.children = None
        self.production = None
        self.h = None
        self.id = None

    def __repr__(self) -> str:
        return 'Node({})'.format(self.nb)

class Root(Node):
    def __init__(self, id=None, nb=None, depth=None, children=None, type=None):
        super().__init__(nb)
        self.id = id
        self.depth = depth
        self.children = children
        self.type = type

    def __repr__(self) -> str:
        return 'Root({}, children={})'.format(self.id, len(self.children))


class Leaf(Node):
    def __init__(self, nb=None, parent=None, lines=None):
        super().__init__(nb)
        self.parent = parent
        self.lines = lines

    def __repr__(self) -> str:
        return 'Leaf({}, parent={})'.format(self.nb, self.parent)

class LineProduction(object):
    def __init__(self, id=None, type=None):
        self.id = id
        self.lhs = type

def writeLattice(n, pos):
    try:
        s = str(pos[n.nb])
    except:
        s = str(n.id)
    for i in n.children:
        s += writeLattice(i, pos)
    return s


class LinesEnumerator(Enumerator):
    z3solver, leaf_prods, ln_prods, p2tree, vars = Solver(), [], [], {}, []

    def initLeafProductions(self):
        for i in self.spec.productions():
            if not i.is_function() or str(i).find('Empty') != -1:
                self.leaf_prods.append(i)

    def initLineProductions(self):
        for l in range(1, self.loc):
            ln_prods = []
            for typ in self.types:
                self.num_prods = self.num_prods + 1
                ln_prods.append(LineProduction(self.num_prods, self.spec.get_type(typ)))
            self.ln_prods.append(ln_prods)

    def findTypes(self):
        types = []
        for i in self.spec.types():
            types.append(i.name[:])
            flg = False
            for prod in self.spec.productions():
                if not prod.is_function() or prod.lhs.name[:] == 'Empty':
                    continue
                if prod.lhs.name[:] == types[-1]:
                    flg = True
                    break
            if not flg:
                types.pop()
        self.types = types
        self.num_types = len(self.types)

    def buildTrees(self):
        
        nds, lfs = [], []
        nb = 1
        for i in range(1, self.loc + 1):
            n = Root(i, nb, self.max_children)
            n.var = self.createRootVariables(nb)
            children = []
            for x in range(self.max_children):
                nb += 1
                child = Leaf(nb, n)
                child.lines = self.createLinesVariables(nb, n.id)

                child.var = self.createLeafVariables(nb, n.id)
                children.append(child)
                lfs.append(child)
            self.propagateEmpty(children)
            n.children = children
            n.type = self.createTypeVariables(n.id)
            nds.append(n)
            nb = nb + 1
        return nds, lfs

    def createLinesVariables(self, nb, p):
        linesvar = []
        for x in range(1, p):
            name = 'l' + str(nb) + "_" + str(x)
            v = Int(name)
            self.linesVars.append(v)
            linesvar.append(v)
            self.z3solver.add(Or(v == 0, v == 1))
            self.num_constraints += 1
        return linesvar

    def createTypeVariables(self, nb):
        name = 't' + str(nb)
        v = Int(name)
        self.typeVars.append(v)
        self.z3solver.add(And(v >= 0, v < self.num_types))
        self.num_constraints += 1
        return v

    def createRootVariables(self, nb):
        name = 'n' + str(nb)
        v = Int(name)
        self.vars.append(v)
        counter = []
        for prods in self.spec.productions():
            if prods not in self.leaf_prods:
                counter.append(v == prods.id)
        self.z3solver.add(Or(counter))
        self.num_constraints += 1
        return v

    def createLeafVariables(self, nb, prnt):
        name = 'n' + str(nb)
        v = Int(name)
        self.vars.append(v)
        counter = []
        vals = self.leaf_prods + [i for a in range(0, prnt - 1) for i in self.ln_prods[a]]
        for p in vals:
            counter.append(v == p.id)
        self.z3solver.add(Or(counter))
        self.num_constraints += 1
        self.parentId[nb] = prnt
        return v

    def propagateEmpty(self, chdrn):
        for i in range(len(chdrn) - 1):
            self.z3solver.add(Implies(chdrn[i].var == 0, chdrn[i + 1].var == 0))
            self.num_constraints += 1

    def createOutputConstraints(self):
        counter = []
        var = self.roots[-1].var
        for prods in self.spec.get_productions_with_lhs(self.spec.output):
            counter.append(var == prods.id)
            for i in range(len(self.roots) - 1):
                self.z3solver.add(self.roots[i].var != prods.id)
        self.z3solver.add(Or(counter))
        self.num_constraints += 1


    def createLinesConstraints(self):
        for r in range(1, len(self.roots)):
            counter = None
            for l in range(len(self.leafs)):
                for v in self.leafs[l].lines:
                    if int(str(v).split("_")[-1]) == r:
                        if counter is None:
                            counter = v
                        else:
                            counter = counter + v
            self.z3solver.add(counter == 1)
            self.num_constraints += 1

    def createInputConstraints(self):
        in_prods = self.spec.get_param_productions()
        for x in range(0, len(in_prods)):
            counter = []
            for y in self.leafs:
                counter.append(y.var == in_prods[x].id)
            self.z3solver.add(Or(counter))
            self.num_constraints += 1

    def createTypeConstraints(self):
        for r in self.roots:
            for t in range(len(self.types)):
                if self.types[t] == 'Empty':
                    continue
                for prods in self.spec.productions():
                    if prods.is_function() and prods.lhs.name[:] == self.types[t]:
                        self.z3solver.add(Implies(r.var == prods.id, r.type == t))
                        self.num_constraints += 1

    def createChildrenConstraints(self):
        for r in self.roots:
            for prods in self.spec.productions():
                if not prods.is_function() or prods.lhs.name[:] == 'Empty':
                    continue
                aux = r.var == prods.id
                for c in range(len(r.children)):
                    counter = []
                    if len(prods.rhs) == c:
                        counter.append(r.children[c].var == self.leaf_prods[0].id)
                        self.num_constraints += 1
                        if len(counter) > 1:
                            self.z3solver.add(Implies(aux, Or(counter)))
                        else:
                            self.z3solver.add(Implies(aux, counter[0]))
                        break
                    for t in self.leaf_prods:
                        if t.lhs.name[:] == prods.rhs[c].name[:]:
                            counter.append(r.children[c].var == t.id)
                    for l in range(r.id - 1):
                        for t in self.ln_prods[l]:
                            if t.lhs.name[:] == prods.rhs[c].name[:]:
                                counter.append(r.children[c].var == t.id)
                                line_var = r.children[c].lines[l]
                                self.z3solver.add(Implies(line_var == 1, r.children[c].var == t.id))
                                self.z3solver.add(Implies(r.children[c].var == t.id, line_var == 1))
                                self.num_constraints += 2
                    self.num_constraints += 1
                    if len(counter) > 1:
                        self.z3solver.add(Implies(aux, Or(counter)))
                    else:
                        self.z3solver.add(Implies(aux, counter[0]))

    def maxChildren(self) -> int:
        maximum = 0
        for prods in self.spec.productions():
            if len(prods.rhs) > maximum:
                maximum = len(prods.rhs)
        return maximum

    @staticmethod
    def _check_arg_types(pre, py_tys):
        if pre.num_args() < len(py_tys):
            msg = 'Predicate "{}" must have at least {} arugments. Only {} is found.'.format(pre.name, len(py_tys), pre.num_args())
            raise ValueError(msg)
        for i, (arg, python_ty) in enumerate(zip(pre.args, py_tys)):
            if not isinstance(arg, python_ty):
                msg = 'Argument {} of predicate {} has unexpected type.'.format(i, pre.name)
                raise ValueError(msg)

    def _resolve_is_not_parent_predicate(self, pre):
        self._check_arg_types(pre, [str, str, (int, float)])
        p0 = self.spec.get_function_production_or_raise(pre.args[0])
        p1 = self.spec.get_function_production_or_raise(pre.args[1])
        for r in self.roots:
            for s in range(len(r.children[0].lines)):
                children = []
                for i in r.children:
                    children.append(i.lines[s] == 1)
                self.z3solver.add(Implies(And(Or(children), self.roots[s].var == p1.id), r.var != p0.id))

    def _resolve_distinct_inputs_predicate(self, pre):
        self._check_arg_types(pre, [str])
        p0 = self.spec.get_function_production_or_raise(pre.args[0])
        for r in self.roots:
            for c1 in range(len(r.children)):
                ch1 = r.children[c1]
                for c2 in range(c1 + 1, len(r.children)):
                    ch2 = r.children[c2]
                    self.z3solver.add(Implies(r.var == p0.id, Or(ch1.var != ch2.var, And(ch1.var == 0, ch2.var == 0))))


    def _resolve_distinct_filters_predicate(self, pre):
        self._check_arg_types(pre, [str])
        p0 = self.spec.get_function_production_or_raise(pre.args[0])
        for r in self.roots:
            self.z3solver.add(Implies(r.var == p0.id, r.children[int(pre.args[1])].var != r.children[int(pre.args[2])].var))


    def _resolve_constant_occurs_predicate(self, pred):
        cond = pred.args[0].split(",")
        lst = []
        for c in cond:
            for prod in self.spec.productions():
                if prod.is_enum() and prod.rhs[0] == c:
                    for l in self.leafs:
                        lst.append(l.var == prod.id)
        self.z3solver.add(Or(lst))

    def _resolve_happens_before_predicate(self, pred):
        pos = pre = 0
        for prod in self.spec.productions():
            if prod.is_enum() and prod.rhs[0] == pred.args[0]:
                pos = prod.id
            if prod.is_enum() and prod.rhs[0] == pred.args[1]:
                pre = prod.id

        for r_i in range(len(self.roots)):
            previous_roots = []
            for r_ia in range(r_i):
                for c in self.roots[r_ia].children:
                    previous_roots.append(c.var == pre)
            self.z3solver.add(Implies(Or([c.var == pos for c in self.roots[r_i].children]), Or(previous_roots)))

    def resolve_predicates(self):
        try:
            for p in self.spec.predicates():
                if p.name == 'is_not_parent':
                    self._resolve_is_not_parent_predicate(p)
                elif p.name == 'distinct_inputs':
                    self._resolve_distinct_inputs_predicate(p)
                elif p.name == 'constant_occurs':
                    self._resolve_constant_occurs_predicate(p)
                elif p.name == 'happens_before':
                    self._resolve_happens_before_predicate(p)
                elif p.name == 'distinct_filters':
                    self._resolve_distinct_filters_predicate(p)
        except (KeyError, ValueError) as e:
            msg = 'Failed. {}'.format(e)
            raise RuntimeError(msg) from None

    def __init__(self, spec, depth=None, loc=None, sym_breaker=True, break_sym_online=False):
        self.z3solver = Solver()
        self.leaf_prods = []
        self.ln_prods = []
        self.p2tree = {}
        self.vars = []
        self.spec = spec
        self.num_constraints = 0
        self.num_variables = 0
        self.sym_breaker = sym_breaker
        self.break_sym_online = break_sym_online
        if depth <= 0:
            raise ValueError('Depth cannot be negative: {}'.format(depth))
        self.depth = depth
        if loc <= 0:
            raise ValueError('Lines of code cannot be negative: {}'.format(loc))
        self.start_time = time.time()
        self.loc = loc
        self.parentId = dict()
        if self.sym_breaker:
            if self.loc > 2:
                root = Node(1)
                root.h = 1
                id, tree = self.createCleanTree(1, root)
                tree.insert(0, root)
                self.cleanedTree = tree
                self.symFinder = SymmetryFinder(self.loc)
            self.lattices = dict()
            if self.loc > 2 and not self.break_sym_online:
                self.findLattices()

        self.cleanedModel = dict()
        self.num_prods = self.spec.num_productions()
        self.max_children = self.maxChildren()
        self.diff_models = []
        self.findTypes()
        self.initLeafProductions()
        self.initLineProductions()
        self.linesVars = []
        self.typeVars = []
        self.roots, self.leafs = self.buildTrees()
        self.model = None

        self.symTime, self.totalSymTime, self.blockingTime, self.blockModelsTime, self.solverTime, self.time1, self.time2, self.time3, self.time4, self.blockedModels, self.totalBlockedModels, self.blockCicle, self.addModel = [0] * 13

        self.modelConstraint = 0
        self.createInputConstraints()
        self.createOutputConstraints()
        self.createLinesConstraints()
        self.createTypeConstraints()
        self.createChildrenConstraints()
        self.resolve_predicates()

        res = self.z3solver.check()
        if res != sat:
            return
        self.model = self.z3solver.model()
        self.getModelConstraint()

    def getParentId(self, nbchd):
        return self.parentId[nbchd]

    def getFirstChild(self, node, pos):
        for c in range(len(node.children)):
            try:

                continue
            except:
                return c
        return len(node.children) - 1

    def findLattices(self):
        lats = open("tyrell/enumerator/lattices/loc-" + str(self.loc), "r+")
        latts = lats.readlines()
        for la in latts:
            lat, mods = la.split(":", 1)
            models = []
            if mods[:-1] != '':
                mods = mods[:-1].replace(" ", "").split("|", self.loc * 2)
                for m in mods:
                    if m == "":
                        continue
                    model = dict()
                    m = m[1:-1].split(",")
                    if m == ['']:
                        break
                    for c in m:
                        c = c.split("=") if "=" in c else c.split(":")
                        model[Int(c[0])] = Int(c[1])
                    models.append(model)
            if lat not in self.lattices:
                self.lattices[lat] = models

    def closeLattices(self):
        if self.loc < 6 or self.break_sym_online or not self.sym_breaker:
            return
        lats = open("tyrell/enumerator/lattices/loc-" + str(self.loc), "w+")
        for l, mdl in self.lattices.items():
            st = l + ":"
            if mdl != []:
                for m in mdl:
                    st += str(m) + "|"
                lats.write(st[:-1] + "\n")
            else:
                lats.write(st + "[]\n")
        lats.close()

    def createCleanTree(self, id, node):
        j = id
        node.children = []
        childs = []
        for i in range(j + 1, j + self.loc):
            l = Node(i)
            l.h = node.h + 1
            l.id = 0
            l.children = []
            id = id + 1
            node.children.append(l)
            childs.append(l)
        for l in node.children:
            if l.h == self.loc:
                break
            id, childs_aux = self.createCleanTree(id, l)
            childs += childs_aux
        return id, childs

    def printTree(self, root):
        for i in root.children:
            print('Id: {} h {} -> Id son {} h {}'.format(root.nb, root.h, i.nb, i.h))
            self.printTree(i)

    def createCompleteLattice(self, n):
        n.children = []
        for c in self.roots[n.nb - 1].children:
            for l in c.lines:
                if self.model[l] == 1:
                    child = Node(int(str(l).split("_")[1]))
                    child.h = n.h + 1
                    self.createCompleteLattice(child)
                    n.children.append(child)

    def createLattice(self, n, nroot, dic):
        for ci in range(len(self.roots[nroot - 1].children)):
            c = self.roots[nroot - 1].children[ci]
            for li in range(len(c.lines)):
                l = c.lines[li]
                if self.model[l] == 1:
                    node_child = n.children[self.getFirstChild(n, dic)]
                    dic[node_child.nb] = li + 1
                    self.createLattice(node_child, li + 1, dic)
                    break

    def findSymmetries(self):
        pos = dict()
        pos[1] = self.loc
        root = self.cleanedTree[0]
        self.createLattice(root, self.loc, pos)
        if not self.break_sym_online and self.loc < 6:
            try:
                return self.lattices[writeLattice(root, pos)]
            except:
                return []
        else:
            lat = writeLattice(root, pos)
            try:
                return self.lattices[lat]
            except:
                last_line = Node(self.loc)
                last_line.h = 0
                self.createCompleteLattice(last_line)
                models = self.symFinder.findSymmetries(last_line)
                self.lattices[lat] = models
                if self.loc > 5 and not self.break_sym_online:
                    self.findLattices()
                    self.closeLattices()
                return models

    def changeNode(self, nodepos, new_nd_pos, new_model, model):
        root, nroot = self.roots[nodepos - 1], self.roots[int(str(new_nd_pos)) - 1]
        for i in range(len(root.children)):
            val = int(str(model[root.children[i].var]))
            if val != 0:
                new_model[nroot.children[i].var] = model[root.children[i].var]
            else:
                new_model[nroot.children[i].var] = self.model[root.children[i].var]
        new_model[nroot.type] = model[root.type]

    def fromSymmetries2Programs(self, model, m_aux):
        for t in range(len(self.typeVars) - 1):
            k = self.typeVars[t]
            m_aux[k] = self.model[k]
            root_num = t + 1
            type = int(str(self.model[k]))
            new_node = int(str(model[Int('x_' + str(root_num))]))
            old_prod = self.ln_prods[root_num - 1][type].id
            new_prod = self.ln_prods[new_node - 1][type].id
            start = root_num * self.max_children
            for i in range(start, len(self.leafs)):
                n = self.leafs[i]
                if self.model[n.var] == old_prod:
                    m_aux[n.var] = IntVal(new_prod)
                    break
        m_aux[self.typeVars[-1]] = self.model[self.typeVars[-1]]
        n_model = dict(m_aux)
        for v in model:
            var, new_nd_pos = v, int(str(model[v]))
            nodepos = int(str(var).split("_")[1])
            n_model[self.roots[new_nd_pos - 1].var] = self.model[self.roots[nodepos - 1].var]
            self.changeNode(nodepos, new_nd_pos, n_model, m_aux)
        n_model[self.roots[-1].var] = self.model[self.roots[-1].var]
        self.changeNode(0, 0, n_model, m_aux)
        return n_model

    def getModelConstraint(self):
        b = []
        for xy in self.vars:
            b.append(xy != Int('val_' + str(xy)))
        self.modelConstraint = Or(b)
        for md in self.model:
            self.cleanedModel[md()] = IntVal(0)

    def blockModelAux(self, model):

        self.z3solver.add(substitute(self.modelConstraint, [(Int('val_' + str(x)), model[x]) for x in self.vars]))

    def blockModel(self):
        assert (self.model is not None)
        self.blockModelAux(self.model)
        if self.sym_breaker and self.loc > 2:
            time1 = time.time()
            models_sols = self.findSymmetries()
            if len(models_sols) > 0:
                for md in models_sols:
                    m2 = dict(self.cleanedModel)

                    self.blockModelAux(self.fromSymmetries2Programs(md, m2))
                    self.blockedModels += 1
            self.symTime = time.time() - time1
            self.totalSymTime += self.symTime

    def update(self, info=None, id=None):
        if info is not None and not isinstance(info, str):
            for c in info:
                counter = []
                for constraint in c:
                    counter.append(self.p2tree[constraint[0]] != constraint[1].id)
                self.z3solver.add(Or(counter))
        else:
            self.blockedModels = 0
            self.blockModel()
            self.totalBlockedModels += self.blockedModels

    def makeNode(self, ch, buildnodes, builder):
        if str(ch.production).find('Empty') == -1:
            if ch.children is None:
                buildnodes[ch.nb - 1] = builder.make_node(ch.production.id, [])
                self.p2tree[buildnodes[ch.nb - 1]] = ch.var
            else:
                children = []
                for rc in ch.children:
                    if buildnodes[rc.nb - 1] is None:
                        self.makeNode(rc, buildnodes, builder)

                    children.append(buildnodes[rc.nb - 1])
                    self.p2tree[buildnodes[rc.nb - 1]] = rc.var

                buildnodes[ch.nb - 1] = builder.make_node(ch.production.id, [ch for ch in children if ch is not None])
                self.p2tree[buildnodes[ch.nb - 1]] = ch.var

    def constructProgram(self):
        m = self.model
        roots = deepcopy(self.roots)
        self.p2tree.clear()
        for r in roots:
            r.production = self.spec.get_production(int(str(m[r.var])))
            for c in r.children:
                c.production = self.spec.get_production(int(str(m[c.var])))
                if c.production is None:
                    for line in c.lines:
                        if m[line] == 1:
                            s = "line_" + str(line).split("_")[1]
                            c.production = s
                            break

        builder = D.Builder(self.spec)
        num_nodes = self.roots + self.leafs
        builder_nodes = [None] * len(num_nodes)

        for r in roots:
            for c in range(len(r.children)):
                if "line_" in str(r.children[c].production):
                    root = int(r.children[c].production.split("_")[1]) - 1
                    r.children[c] = roots[root]
            self.makeNode(r, builder_nodes, builder)
        return builder_nodes[roots[-1].nb - 1]

    def next(self):
        while True:
            s_time = time.time()
            result = self.z3solver.check()
            self.solverTime += time.time() - s_time
            if result != sat:
                return None
            self.model = self.z3solver.model()
            if self.model is not None:
                return self.constructProgram()
            else:
                return None
