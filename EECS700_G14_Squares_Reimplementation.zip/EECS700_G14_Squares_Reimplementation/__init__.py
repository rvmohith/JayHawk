from .squaresEnumerator import *
