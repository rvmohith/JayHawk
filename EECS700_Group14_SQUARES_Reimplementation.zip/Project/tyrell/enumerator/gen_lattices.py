from sys import argv, stderr
from .lines import *

def blockModelAux(variables, model, solver):
    block = []
    for x in variables:
        block.append(x != model[x])
    solver.add(Or(block))

def getModels(solver, vars):
    m = []
    while True:
            if solver.check() != sat:
                break
            if solver.model() is not None:
                m.append(solver.model())
                blockModelAux(vars, solver.model(), solver)
    return m

def getModel(solver, vars):
    if solver.check() != sat:
        return
    if solver.model() is not None:
        blockModelAux(vars, solver.model(), solver)
        return solver.model()


def printModels(mod):
    s = ''
    for m in mod:
        s += str(m) + "|"
    return s[:-1]

def writeLattice(node):
    s = str(node.nb)
    for i in node.children:
        s += writeLattice(i)
    return s
    
class SymmetryFinder(object):

    def __init__(self, loc):
        self.loc = loc

    def getChildrenNonZero(self, child):
        count = 0
        for i in child:
            if i.nb != 0:
                count = count + 1
        return count

    def getSymmetryConstraints(self, n, pid):
        if n.nb == 0:
            return [], [], []
        name = 'x_' +str(n.nb)
        n.var = Int(name)
        if n.children != []:
            res, vars, cur_val = [And(self.getChildrenNonZero(n.children) < n.var, n.var < pid)], [n.var], [n.var!=n.nb]

            for i in node.children:
                vars_aux, res_aux, cur_val_aux = self.getSymmetryConstraints(i, n.var)
                res = res + res_aux
                vars = vars + vars_aux
                cur_val = cur_val + cur_val_aux
            return vars, res, cur_val
        else:
            return [n.var], [And(1 <= n.var,n.var < pid)], [n.var!=n.nb]

    def allDiff(self, var, solver):
        for v in range(len(var)):
            for v_1 in range(v+1,len(var)):
                if var[v] is not var[v_1]:
                    solver.add(var[v]!=var[v_1])

    def findSymmetries(self, l_line):
        constraints = []
        all_vars = []
        current_values = []

        for i in l_line.children:
            if i.nb == 0:
                continue
            vaux, caux, cval = self.getSymmetryConstraints(i, l_line.nb)
            all_vars = all_vars + vaux
            constraints = constraints +caux
            current_values =current_values + cval

        sym_solver = Solver()
        sym_solver.add(Or(current_values))
        sym_solver.add(constraints)
        self.allDiff(all_vars, sym_solver)
        return getModels(sym_solver, all_vars)

class LatticeBuilder(object):

    def __init__(self, loc):
        self.loc = loc
        self.sym_finder = SymmetryFinder(self.loc)

    def createTree(self, id, n):
        k = id
        n.children = []
        for i in range(k+1, k+self.loc):
            l = Node(i)
            l.h = n.h + 1
            name = 'x_' +str(l.nb)
            l.var = Int(name)
            l.children = []
            id += 1
            n.children.append(l)

        for l in n.children:
            if l.h == self.loc:
                break
            id = self.createTree(id, l)
        return id

    def printTree(self, r):

        for i in r.children:
            print('Id: {} h {} var {} -> Id son {} h {} var {}'.format(r.nb, r.h, r.var, i.nb, i.h, i.var))
            self.printTree(i)

    def Constraints(self, n):
        res = [Or(And(1 <= n.var, n.var < self.loc), n.var == 0)]
        vars = [n.var]
        prechild = None
        for i in n.children:
            res = res + [Implies(n.var == 0, i.var == 0)]
            if prechild is not None:
                res = res + [Implies(prechild.var == 0, i.var == 0)]

            res = res + [Or(n.var > i.var, n.var == 0)]
            res_aux, vars_aux = self.Constraints(i)
            res = res + res_aux
            vars = vars + vars_aux
            prechild = i
        return res, vars

    def createLattice(self, lnode, n, model):
        lnode.children = []
        for i in n.children:
            val = int(str(model[i.var]))
            child = Node(val)
            if val !=0:
                name = 'x_' +str(val)
                child.var = Int(name)
            child.h = lnode.h + 1
            self.createLattice(child, i, model)
            lnode.children.append(child)

    def printLattice(self, r):
        for i in r.children:
            print('Id: {} h {} -> Id son {} h {}'.format(r.nb, r.h, i.nb, i.h))
            self.printTree(i)

    def genLattices(self):
        r = Node(1)
        r.h = 1
        name = 'x_' +str(r.nb)
        r.var = Int(name)
        self.createTree(1, r)
        Solver().add(r.var==self.loc)
        constraints, vars = [], []
        prechild = None
        for i in r.children:
            consts_aux, vars_aux = self.Constraints(i)
            constraints = constraints + consts_aux
            if prechild is not None:
                constraints = constraints + [Implies(prechild.var == 0, i.var == 0)]
            prechild = i
            vars = vars + vars_aux

        Solver().add(constraints)
        for v in range(len(vars)):
            for v_1 in range(v+1,len(vars)):
                if vars[v] is not vars[v_1]:
                    Solver().add(Or(vars[v]!=vars[v_1],And(vars[v]==0,vars[v_1]==0)))

        for i in range(1,self.loc):
            lst = []
            for v in vars:
                lst.append(v==i)
            Solver().append(Or(lst))

        while True:
            model = getModel(Solver(), vars)
            if model is None:
                break
            l_line = Node(self.loc)
            l_line.h = 0
            self.createLattice(l_line, r, model)
            m = self.sym_finder.findSymmetries(l_line)
            print(writeLattice(l_line), file=sys.stderr)
            print(writeLattice(l_line)+":"+printModels(m))


if __name__ == '__main__':
    if len(argv)!= 2:
        exit("Usage: python3 gen_lattices.py loc")
    latticebuilder = LatticeBuilder(int(argv[-1]))
    latticebuilder.genLattices()
